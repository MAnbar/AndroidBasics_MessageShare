package com.example.cameraapp;

import android.Manifest;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;

import com.example.cameraapp.adapters.ImageAdapter;

import java.io.File;

public class ViewActivity extends AppCompatActivity {
    // Storage Permissions
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    int[] imageId = {
            R.drawable.a,
            R.drawable.b,
            R.drawable.c,
            R.drawable.d,
            R.drawable.e,
            R.drawable.f,
    };
    public  void loadImages(String path){
        File directory = new File(path); //path is the string specifying your directory path.
        File[] files = directory.listFiles();
        for (int i = 0; i < files.length; i++)
        {
            System.out.println("FileName: " + files[i].getName()); //these are the different filenames in the directory

        //You can now use these file names along with the directory path and convert the image there to a bitmap and set it to recycler view's image view

            File imgFile = new  File(path + files[i].getName());
            if(imgFile.exists()){

                Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath()); //this is the bitmap for the image
                ImageView myImage = (ImageView) findViewById(R.id.grid_item_image);//your image view in the recycler view
                myImage.setImageBitmap(myBitmap);//image set to the image view

            };
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        loadImages(storageDir.getAbsolutePath());
        ImageAdapter adapter = new ImageAdapter(ViewActivity.this,imageId);
        GridView grid=(GridView)findViewById(R.id.grid_view);
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,int position, long id) {

            }
        });
    }
}
